package service;

import model.user;
import util.DBConnectionUtil;


import java.sql.*;


public class loginService {
    static Connection con;



    //login validation
    public int login(user u){

        String username = u.getUsername();
        String password = u.getPassword();

        Connection con = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String userNameDB = "";
        String passwordDB = "";
        int roleDB;

        try
        {
            con = DBConnectionUtil.getConnection();
            statement = con.createStatement();
            resultSet = statement.executeQuery("select username,password,user_type from user");

            while(resultSet.next())
            {
                userNameDB = resultSet.getString("username");
                passwordDB = resultSet.getString("password");
                roleDB = resultSet.getInt("user_type");

                if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB== 0)
                    return 0;
                else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB==1)
                    return 1;
                else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB==2)
                    return 2;
                else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB==3)
                    return 3;
                else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB==4)
                    return 4;
                else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB==5)
                    return 5;
                else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB==6)
                    return 6;
            }
        }
        catch(SQLException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return -1;
    }
}

