package servlet;

import model.user;
import service.loginService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userName = request.getParameter("username");
        String password = request.getParameter("password");
        String user_id = request.getParameter("user_id");

       user u = new user();

        u.setUsername(userName);
        u.setPassword(password);
        u.setUser_id(user_id);

        loginService loginDao = new loginService();

        try
        {
           int userValidate = loginDao.login(u);

            if(userValidate == 0)
            {
                HttpSession session = request.getSession(); //Creating a session
                session.setAttribute("user_id", user_id); //setting session attribute



                request.getRequestDispatcher("admin.jsp").forward(request, response);
            }
            else if(userValidate == 1)
            {
                HttpSession session = request.getSession(); //Creating a session
                session.setAttribute("user_id", user_id); //setting session attribute


                request.getRequestDispatcher("nurse.jsp").forward(request, response);
            }
            else if(userValidate == 2)
            {
                HttpSession session = request.getSession(); //Creating a session
                session.setAttribute("user_id", user_id); //setting session attribute


                request.getRequestDispatcher(" ").forward(request, response);
            }
            else if(userValidate == 3)
            {

                HttpSession session = request.getSession(); //Creating a session
                session.setAttribute("user_id", user_id); //setting session attribute

                request.getRequestDispatcher(" ").forward(request, response);
            }
            else if(userValidate == 4)
            {

                HttpSession session = request.getSession(); //Creating a session
                session.setAttribute("user_id", user_id); //setting session attribute

                request.getRequestDispatcher(" ").forward(request, response);
            } else if(userValidate == 5)
            {
                HttpSession session = request.getSession(); //Creating a session
                session.setAttribute("user_id", user_id); //setting session attribute


                request.getRequestDispatcher(" ").forward(request, response);
            }

            else
            {
                HttpSession session = request.getSession(); //Creating a session
                session.setAttribute("user_id", user_id); //setting session attribute


                request.getRequestDispatcher("").forward(request, response);
            }
        }
        catch (IOException e1)
        {
            e1.printStackTrace();
        }
        catch (Exception e2)
        {
            e2.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
