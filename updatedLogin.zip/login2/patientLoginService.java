package service;

import util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;

public class patientLoginService {
   private Connection con;
    public boolean login(String username, String password){

        boolean st = false;
        try{
            con = DBConnectionUtil.getConnection();
            PreparedStatement preparedStatement = con.prepareStatement("select u.username,u.password from user u,patient p where u.user_id = p.patientID and u.username=? and u.password=? ");
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);


            ResultSet rs = preparedStatement.executeQuery();
            st  = rs.next();

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();

        }


        return st;
    }
}
